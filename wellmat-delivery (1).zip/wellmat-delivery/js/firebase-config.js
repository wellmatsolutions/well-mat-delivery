// =====================================================================
// CẤU HÌNH FIREBASE — điền thông tin dự án Firebase của bạn vào đây.
// Xem hướng dẫn lấy các giá trị này trong README.md (Bước 1).
// =====================================================================
export const firebaseConfig = {
  apiKey: "DÁN_API_KEY_VÀO_ĐÂY",
  authDomain: "TÊN-DỰ-ÁN.firebaseapp.com",
  projectId: "TÊN-DỰ-ÁN",
  storageBucket: "TÊN-DỰ-ÁN.appspot.com",
  messagingSenderId: "DÁN_SENDER_ID",
  appId: "DÁN_APP_ID"
};

// Thông tin công ty — dùng làm mặc định trên mọi phiếu giao hàng.
export const COMPANY = {
  name: "CÔNG TY TNHH WELL MAT SOLUTIONS",
  address: "Tầng 5, 231-233 Lê Thánh Tôn, Phường Bến Thành, TP Hồ Chí Minh, Việt Nam",
  hotline: "Hotline kỹ thuật 24/7: +84 384 871 216",
  email: "sales@well-mat.com",
  // Đặt file logo tại assets/logo.png và file con dấu tại assets/stamp.png
  logo: "assets/logo.png",
  stamp: "assets/stamp.png"
};
